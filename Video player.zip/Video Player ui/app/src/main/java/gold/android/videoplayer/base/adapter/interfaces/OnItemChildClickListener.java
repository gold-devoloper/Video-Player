package gold.android.videoplayer.base.adapter.interfaces;

import android.view.View;

public interface OnItemChildClickListener {
    void onItemClick(View view, int position, long itemId);
}