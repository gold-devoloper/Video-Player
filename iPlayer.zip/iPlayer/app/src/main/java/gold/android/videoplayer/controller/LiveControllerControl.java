package gold.android.videoplayer.controller;

import android.content.Context;
import gold.android.iplayer.base.BaseController;

public class LiveControllerControl extends BaseController {

    public LiveControllerControl(Context context) {
        super(context);
    }

    @Override
    public int getLayoutId() {
        return 0;
    }

    @Override
    public void initViews() {

    }
}