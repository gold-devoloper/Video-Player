package gold.android.videoplayer.base.adapter.interfaces;

public interface MultiItemEntity {

    int getItemType();
}