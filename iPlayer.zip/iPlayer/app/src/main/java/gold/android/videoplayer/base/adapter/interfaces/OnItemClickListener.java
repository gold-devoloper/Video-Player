package gold.android.videoplayer.base.adapter.interfaces;

import android.view.View;

public interface OnItemClickListener {
    void onItemClick(View view, int position, long itemId);
}